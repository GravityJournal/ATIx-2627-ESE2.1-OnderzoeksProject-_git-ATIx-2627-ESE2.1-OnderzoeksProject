#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <thread>
#include <chrono>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

using namespace std;

// Function to execute ping command and capture first line
string executePingAndCapture(const string& ip, vector<string>& outputLines) {
    // Linux: ping with 2 pings and 2 second timeout
    string command = "ping -c 2 -W 2 " + ip + " 2>&1";

    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        cerr << "Error: Could not execute ping command!" << endl;
        return "";
    }

    char buffer[256];
    string firstLine = "";
    bool firstLineCapture = false;

    // Read output line by line
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        string line(buffer);

        // Remove trailing newline
        if (!line.empty() && line[line.length()-1] == '\n') {
            line.erase(line.length()-1);
        }

        // Capture first non-empty line
        if (!firstLineCapture && !line.empty()) {
            firstLine = line;
            firstLineCapture = true;
        }

        outputLines.push_back(line);
    }

    pclose(pipe);
    return firstLine;
}

// Function to clear ARP table
bool clearARPTable() {
    cout << "\n=== Clearing ARP Table ===" << endl;

    // Try ip command first (modern Linux)
    cout << "Attempting to flush neighbor table..." << endl;
    int result = system("ip neigh flush all 2>/dev/null");

    if (result == 0) {
        cout << "✓ ARP table cleared successfully using 'ip neigh flush all'!" << endl;
        return true;
    }

    // Fallback to arp command (older systems)
    cout << "Attempting fallback method with 'arp -d'..." << endl;
    result = system("arp -d -a 2>/dev/null || arp -n | awk '/^[0-9]/ {system(\"arp -d \" $1)}' 2>/dev/null");

    if (result == 0) {
        cout << "✓ ARP table cleared successfully!" << endl;
        return true;
    }

    cerr << "✗ Warning: Could not clear ARP table (exit code: " << result << ")" << endl;
    cerr << "  This program may need to be run with sudo privileges:" << endl;
    cerr << "  sudo ./ping_arp" << endl;
    return false;
}

// Function to check if running as root
bool isRoot() {
    return geteuid() == 0;
}

int main() {
    string ip;
    vector<string> pingOutput;

    cout << "╔═══════════════════════════════════════╗" << endl;
    cout << "║  Ping and ARP Clear Utility (Linux)   ║" << endl;
    cout << "╚═══════════════════════════════════════╝" << endl;

    // Check if running as root
    if (!isRoot()) {
        cout << "\n⚠ Warning: Not running as root. ARP table clearing may fail." << endl;
        cout << "  Consider running with: sudo ./ping_arp\n" << endl;
    }

    cout << "\nEnter IP address to ping: ";
    getline(cin, ip);

    // Validate IP is not empty
    if (ip.empty()) {
        cerr << "Error: IP address cannot be empty!" << endl;
        return 1;
    }

    cout << "\n=== Executing Ping ===" << endl;
    cout << "Target: " << ip << endl;
    cout << "Duration: ~2 seconds (2 packets)" << endl;
    cout << "\nPinging..." << endl;

    // Execute ping and capture output
    string firstLine = executePingAndCapture(ip, pingOutput);

    // Display results
    cout << "\n=== Ping Results ===" << endl;
    if (!firstLine.empty()) {
        cout << "\n📌 First line captured:" << endl;
        cout << "   " << firstLine << endl;
    } else {
        cout << "No output captured from ping command." << endl;
    }

    cout << "\n📄 Full output (" << pingOutput.size() << " lines):" << endl;
    cout << "─────────────────────────────────────────" << endl;
    for (const auto& line : pingOutput) {
        cout << line << endl;
    }
    cout << "─────────────────────────────────────────" << endl;

    // Clear ARP table
    clearARPTable();

    cout << "\n✓ Program completed successfully!" << endl;
    
    return 0;
}