#include <iostream>
#include <cstdlib>
#include <string>
#include <memory>
#include <array>
#include <vector>

// Function to execute command and capture output
std::string executeCommand(const std::string& cmd) {
    std::array<char, 128> buffer;
    std::string result;

    // Open pipe to command with read mode
    FILE* pipe = popen(cmd.c_str(), "r");

    if (!pipe) {
        return "Error: Failed to execute command";
    }

    // Read command output
    while (fgets(buffer.data(), buffer.size(), pipe) != nullptr) {
        result += buffer.data();
    }

    // Close pipe
    pclose(pipe);

    return result;
}

std::string executeCommandFirstLine(const std::string& cmd) {
    std::array<char, 128> buffer;
    std::string result;

    // Open pipe to command with read mode
    FILE* pipe = popen(cmd.c_str(), "r");

    if (!pipe) {
        return "Error: Failed to execute command";
    }

    // Read only the first line
    if (fgets(buffer.data(), buffer.size(), pipe) != nullptr) {
        result = buffer.data();
        // Remove trailing newline if present
        if (!result.empty() && result.back() == '\n') {
            result.pop_back();
        }
    }

    // Close pipe
    pclose(pipe);

    return result;
}

int main() {
    std::string command;
    int choice;
    std::string firstLine = executeCommandFirstLine(command);
    std::vector<std::string> toCalculate;
    std::cout << "=== CMD Command Executor ===" << std::endl;
    std::cout << "1. Execute with output capture" << std::endl;
    std::cout << "2. Execute normally (direct output)" << std::endl;
    std::cout << "Type 'exit' to quit" << std::endl;
    std::cout << "================================" << std::endl << std::endl;

    while (true) {
        std::cout << "Enter command: ";
        std::getline(std::cin, command);

        // Exit condition
        if (command == "exit") {
            std::cout << "Exiting..." << std::endl;
            break;
        }

        // Skip empty commands
        if (command.empty()) {
            continue;
        }

        std::cout << "\nChoose execution mode (1 or 2): ";
        std::cin >> choice;
        std::cin.ignore(); // Clear newline

        std::cout << "\nExecuting: " << command << std::endl;
        std::cout << "----------------------------" << std::endl;

        if (choice == 1) {
            // Capture and display output
            std::string output = executeCommand(command);
            std::cout << output;
        } else if (choice == 2) {
        // Capture and display first line only
        std::cout << "First line: " << firstLine << std::endl;
        }else {
            // Direct execution
            int result = system(command.c_str());
            std::cout << "\nCommand returned: " << result << std::endl;
        }

        // store firstLine in the vector
        toCalculate.push_back(firstLine);
        std::cout << toCalculate.size() << std::endl;
        std::cout << toCalculate[0] << std::endl;
        //print vector contents for debugging
        for (std::string calc : toCalculate) {
            std::cout << calc << std::endl;
        }

        std::cout << "----------------------------" << std::endl << std::endl;
    }

    return 0;
}