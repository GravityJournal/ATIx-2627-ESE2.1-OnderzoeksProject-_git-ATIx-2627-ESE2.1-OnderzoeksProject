CMakeFiles/cmdWriter.dir/main.cpp.o.ddi: \
 /home/supag/CLionProjects/cmdWriter/main.cpp /usr/include/stdc-predef.h \
 /usr/include/c++/15.2.0/iostream \
 /usr/include/c++/15.2.0/bits/requires_hosted.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/c++config.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/cpu_defines.h \
 /usr/include/c++/15.2.0/pstl/pstl_config.h \
 /usr/include/c++/15.2.0/ostream /usr/include/c++/15.2.0/bits/ostream.h \
 /usr/include/c++/15.2.0/ios /usr/include/c++/15.2.0/iosfwd \
 /usr/include/c++/15.2.0/bits/stringfwd.h \
 /usr/include/c++/15.2.0/bits/memoryfwd.h \
 /usr/include/c++/15.2.0/bits/postypes.h /usr/include/c++/15.2.0/cwchar \
 /usr/include/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/x86_64-linux-gnu/bits/floatn.h \
 /usr/include/x86_64-linux-gnu/bits/floatn-common.h \
 /usr/lib/gcc/x86_64-unknown-linux-gnu/15.2.0/include/stddef.h \
 /usr/lib/gcc/x86_64-unknown-linux-gnu/15.2.0/include/stdarg.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/types/wint_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/mbstate_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/c++/15.2.0/exception \
 /usr/include/c++/15.2.0/bits/exception.h \
 /usr/include/c++/15.2.0/bits/version.h \
 /usr/include/c++/15.2.0/bits/exception_ptr.h \
 /usr/include/c++/15.2.0/bits/exception_defines.h \
 /usr/include/c++/15.2.0/bits/cxxabi_init_exception.h \
 /usr/include/c++/15.2.0/typeinfo \
 /usr/include/c++/15.2.0/bits/hash_bytes.h /usr/include/c++/15.2.0/new \
 /usr/include/c++/15.2.0/bits/move.h /usr/include/c++/15.2.0/type_traits \
 /usr/include/c++/15.2.0/bits/nested_exception.h \
 /usr/include/c++/15.2.0/bits/char_traits.h \
 /usr/include/c++/15.2.0/compare /usr/include/c++/15.2.0/concepts \
 /usr/include/c++/15.2.0/bits/stl_construct.h \
 /usr/include/c++/15.2.0/bits/stl_iterator_base_types.h \
 /usr/include/c++/15.2.0/bits/iterator_concepts.h \
 /usr/include/c++/15.2.0/bits/ptr_traits.h \
 /usr/include/c++/15.2.0/bits/ranges_cmp.h \
 /usr/include/c++/15.2.0/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/15.2.0/bits/concept_check.h \
 /usr/include/c++/15.2.0/debug/assertions.h \
 /usr/include/c++/15.2.0/bits/localefwd.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/c++locale.h \
 /usr/include/c++/15.2.0/clocale /usr/include/locale.h \
 /usr/include/x86_64-linux-gnu/bits/locale.h \
 /usr/include/c++/15.2.0/cctype /usr/include/ctype.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endianness.h \
 /usr/include/c++/15.2.0/bits/ios_base.h \
 /usr/include/c++/15.2.0/ext/atomicity.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/gthr.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/gthr-default.h \
 /usr/lib/gcc/x86_64-unknown-linux-gnu/15.2.0/include-fixed/pthread.h \
 /usr/include/sched.h /usr/include/x86_64-linux-gnu/bits/types/time_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/x86_64-linux-gnu/bits/sched.h \
 /usr/include/linux/sched/types.h /usr/include/linux/types.h \
 /usr/include/x86_64-linux-gnu/asm/types.h \
 /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
 /usr/include/x86_64-linux-gnu/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h \
 /usr/include/x86_64-linux-gnu/asm/posix_types.h \
 /usr/include/x86_64-linux-gnu/asm/posix_types_64.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_sched_param.h \
 /usr/include/x86_64-linux-gnu/bits/cpu-set.h /usr/include/time.h \
 /usr/include/x86_64-linux-gnu/bits/time.h \
 /usr/include/x86_64-linux-gnu/bits/timex.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/x86_64-linux-gnu/bits/types/clock_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_tm.h \
 /usr/include/x86_64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/timer_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_itimerspec.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/x86_64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/x86_64-linux-gnu/bits/struct_mutex.h \
 /usr/include/x86_64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/x86_64-linux-gnu/bits/setjmp.h \
 /usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct___jmp_buf_tag.h \
 /usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/atomic_word.h \
 /usr/include/x86_64-linux-gnu/sys/single_threaded.h \
 /usr/include/c++/15.2.0/bits/locale_classes.h \
 /usr/include/c++/15.2.0/string /usr/include/c++/15.2.0/bits/allocator.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/c++allocator.h \
 /usr/include/c++/15.2.0/bits/new_allocator.h \
 /usr/include/c++/15.2.0/bits/functexcept.h \
 /usr/include/c++/15.2.0/bits/cpp_type_traits.h \
 /usr/include/c++/15.2.0/bits/ostream_insert.h \
 /usr/include/c++/15.2.0/bits/cxxabi_forced.h \
 /usr/include/c++/15.2.0/bits/stl_iterator.h \
 /usr/include/c++/15.2.0/ext/type_traits.h \
 /usr/include/c++/15.2.0/bits/utility.h \
 /usr/include/c++/15.2.0/bits/stl_function.h \
 /usr/include/c++/15.2.0/backward/binders.h \
 /usr/include/c++/15.2.0/ext/numeric_traits.h \
 /usr/include/c++/15.2.0/bits/stl_algobase.h \
 /usr/include/c++/15.2.0/bits/stl_pair.h \
 /usr/include/c++/15.2.0/debug/debug.h \
 /usr/include/c++/15.2.0/bits/predefined_ops.h \
 /usr/include/c++/15.2.0/bit /usr/include/c++/15.2.0/bits/refwrap.h \
 /usr/include/c++/15.2.0/bits/invoke.h \
 /usr/include/c++/15.2.0/bits/range_access.h \
 /usr/include/c++/15.2.0/initializer_list \
 /usr/include/c++/15.2.0/bits/basic_string.h \
 /usr/include/c++/15.2.0/ext/alloc_traits.h \
 /usr/include/c++/15.2.0/bits/alloc_traits.h \
 /usr/include/c++/15.2.0/string_view \
 /usr/include/c++/15.2.0/bits/functional_hash.h \
 /usr/include/c++/15.2.0/bits/ranges_base.h \
 /usr/include/c++/15.2.0/bits/max_size_type.h \
 /usr/include/c++/15.2.0/numbers \
 /usr/include/c++/15.2.0/bits/string_view.tcc \
 /usr/include/c++/15.2.0/bits/ranges_algobase.h \
 /usr/include/c++/15.2.0/bits/ranges_util.h \
 /usr/include/c++/15.2.0/ext/string_conversions.h \
 /usr/include/c++/15.2.0/cstdlib /usr/include/stdlib.h \
 /usr/include/x86_64-linux-gnu/bits/waitflags.h \
 /usr/include/x86_64-linux-gnu/bits/waitstatus.h \
 /usr/include/x86_64-linux-gnu/sys/types.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/x86_64-linux-gnu/bits/byteswap.h \
 /usr/include/x86_64-linux-gnu/bits/uintn-identity.h \
 /usr/include/x86_64-linux-gnu/sys/select.h \
 /usr/include/x86_64-linux-gnu/bits/select.h \
 /usr/include/x86_64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/alloca.h /usr/include/x86_64-linux-gnu/bits/stdlib-float.h \
 /usr/include/c++/15.2.0/bits/std_abs.h /usr/include/c++/15.2.0/cstdio \
 /usr/include/stdio.h /usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/cookie_io_functions_t.h \
 /usr/include/x86_64-linux-gnu/bits/stdio_lim.h \
 /usr/include/c++/15.2.0/cerrno /usr/include/errno.h \
 /usr/include/x86_64-linux-gnu/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/x86_64-linux-gnu/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/x86_64-linux-gnu/bits/types/error_t.h \
 /usr/include/c++/15.2.0/bits/charconv.h \
 /usr/include/c++/15.2.0/bits/basic_string.tcc \
 /usr/include/c++/15.2.0/bits/memory_resource.h \
 /usr/include/c++/15.2.0/cstddef \
 /usr/include/c++/15.2.0/bits/uses_allocator.h \
 /usr/include/c++/15.2.0/bits/uses_allocator_args.h \
 /usr/include/c++/15.2.0/tuple \
 /usr/include/c++/15.2.0/bits/locale_classes.tcc \
 /usr/include/c++/15.2.0/system_error \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/error_constants.h \
 /usr/include/c++/15.2.0/stdexcept /usr/include/c++/15.2.0/streambuf \
 /usr/include/c++/15.2.0/bits/streambuf.tcc \
 /usr/include/c++/15.2.0/bits/basic_ios.h \
 /usr/include/c++/15.2.0/bits/locale_facets.h \
 /usr/include/c++/15.2.0/cwctype /usr/include/wctype.h \
 /usr/include/x86_64-linux-gnu/bits/wctype-wchar.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/ctype_base.h \
 /usr/include/c++/15.2.0/bits/streambuf_iterator.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/ctype_inline.h \
 /usr/include/c++/15.2.0/bits/locale_facets.tcc \
 /usr/include/c++/15.2.0/bits/basic_ios.tcc \
 /usr/include/c++/15.2.0/format /usr/include/c++/15.2.0/array \
 /usr/include/c++/15.2.0/charconv /usr/include/c++/15.2.0/limits \
 /usr/include/c++/15.2.0/locale \
 /usr/include/c++/15.2.0/bits/locale_facets_nonio.h \
 /usr/include/c++/15.2.0/ctime \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/time_members.h \
 /usr/include/c++/15.2.0/x86_64-unknown-linux-gnu/bits/messages_members.h \
 /usr/include/libintl.h /usr/include/c++/15.2.0/bits/codecvt.h \
 /usr/include/c++/15.2.0/bits/locale_facets_nonio.tcc \
 /usr/include/c++/15.2.0/bits/locale_conv.h \
 /usr/include/c++/15.2.0/optional \
 /usr/include/c++/15.2.0/bits/enable_special_members.h \
 /usr/include/c++/15.2.0/span /usr/include/c++/15.2.0/bits/monostate.h \
 /usr/include/c++/15.2.0/bits/formatfwd.h \
 /usr/include/c++/15.2.0/bits/unicode.h /usr/include/c++/15.2.0/cstdint \
 /usr/lib/gcc/x86_64-unknown-linux-gnu/15.2.0/include/stdint.h \
 /usr/include/stdint.h /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-least.h \
 /usr/include/c++/15.2.0/bits/stl_algo.h \
 /usr/include/c++/15.2.0/bits/algorithmfwd.h \
 /usr/include/c++/15.2.0/bits/stl_heap.h \
 /usr/include/c++/15.2.0/bits/uniform_int_dist.h \
 /usr/include/c++/15.2.0/bits/stl_tempbuf.h \
 /usr/include/c++/15.2.0/bits/unicode-data.h \
 /usr/include/c++/15.2.0/bits/ostream.tcc /usr/include/c++/15.2.0/istream \
 /usr/include/c++/15.2.0/bits/istream.tcc /usr/include/c++/15.2.0/memory \
 /usr/include/c++/15.2.0/bits/stl_uninitialized.h \
 /usr/include/c++/15.2.0/bits/stl_raw_storage_iter.h \
 /usr/include/c++/15.2.0/bits/align.h \
 /usr/include/c++/15.2.0/bits/unique_ptr.h \
 /usr/include/c++/15.2.0/bits/shared_ptr.h \
 /usr/include/c++/15.2.0/bits/shared_ptr_base.h \
 /usr/include/c++/15.2.0/bits/allocated_ptr.h \
 /usr/include/c++/15.2.0/ext/aligned_buffer.h \
 /usr/include/c++/15.2.0/ext/concurrence.h \
 /usr/include/c++/15.2.0/bits/shared_ptr_atomic.h \
 /usr/include/c++/15.2.0/bits/atomic_base.h \
 /usr/include/c++/15.2.0/bits/atomic_lockfree_defines.h \
 /usr/include/c++/15.2.0/bits/atomic_wait.h \
 /usr/include/c++/15.2.0/climits \
 /usr/lib/gcc/x86_64-unknown-linux-gnu/15.2.0/include/limits.h \
 /usr/lib/gcc/x86_64-unknown-linux-gnu/15.2.0/include/syslimits.h \
 /usr/include/limits.h /usr/include/x86_64-linux-gnu/bits/posix1_lim.h \
 /usr/include/x86_64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/x86_64-linux-gnu/bits/posix2_lim.h \
 /usr/include/x86_64-linux-gnu/bits/xopen_lim.h \
 /usr/include/x86_64-linux-gnu/bits/uio_lim.h /usr/include/unistd.h \
 /usr/include/x86_64-linux-gnu/bits/posix_opt.h \
 /usr/include/x86_64-linux-gnu/bits/environments.h \
 /usr/include/x86_64-linux-gnu/bits/confname.h \
 /usr/include/x86_64-linux-gnu/bits/getopt_posix.h \
 /usr/include/x86_64-linux-gnu/bits/getopt_core.h \
 /usr/include/x86_64-linux-gnu/bits/unistd_ext.h \
 /usr/include/linux/close_range.h /usr/include/syscall.h \
 /usr/include/x86_64-linux-gnu/sys/syscall.h \
 /usr/include/x86_64-linux-gnu/asm/unistd.h \
 /usr/include/x86_64-linux-gnu/asm/unistd_64.h \
 /usr/include/x86_64-linux-gnu/bits/syscall.h \
 /usr/include/c++/15.2.0/bits/std_mutex.h \
 /usr/include/c++/15.2.0/backward/auto_ptr.h \
 /usr/include/c++/15.2.0/bits/ranges_uninitialized.h \
 /usr/include/c++/15.2.0/bits/out_ptr.h \
 /usr/include/c++/15.2.0/pstl/glue_memory_defs.h \
 /usr/include/c++/15.2.0/pstl/execution_defs.h \
 /usr/include/c++/15.2.0/vector /usr/include/c++/15.2.0/bits/stl_vector.h \
 /usr/include/c++/15.2.0/bits/stl_bvector.h \
 /usr/include/c++/15.2.0/bits/vector.tcc
