#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <thread>
#include <chrono>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

using namespace std;

// Function to extract ping times from a line
vector<double> extractPingTimes(const string& line) {
    vector<double> times;
    size_t pos = line.find("time=");

    if (pos != string::npos) {
        // Extract the time value after "time="
        string timeStr = line.substr(pos + 5);
        size_t endPos = timeStr.find(" ");
        if (endPos != string::npos) {
            timeStr = timeStr.substr(0, endPos);
        }

        try {
            double time = stod(timeStr);
            times.push_back(time);
        } catch (...) {
            // Ignore parsing errors
        }
    }

    return times;
}

// Function to execute ping command and capture first line and times
string executePingAndCapture(const string& ip, vector<string>& outputLines, vector<double>& pingTimes) {
    // Linux: ping with 2 pings and 2 second timeout
    string command = "ping -c 2 -W 2 " + ip + " 2>&1";

    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        cerr << "Error: Could not execute ping command!" << endl;
        return "";
    }

    char buffer[256];
    string firstLine = "";
    bool firstLineCapture = false;

    // Read output line by line
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        string line(buffer);

        // Remove trailing newline
        if (!line.empty() && line[line.length()-1] == '\n') {
            line.erase(line.length()-1);
        }

        // Capture first non-empty line
        if (!firstLineCapture && !line.empty()) {
            firstLine = line;
            firstLineCapture = true;
        }

        // Extract ping times from lines
        vector<double> times = extractPingTimes(line);
        pingTimes.insert(pingTimes.end(), times.begin(), times.end());

        outputLines.push_back(line);
    }

    pclose(pipe);
    return firstLine;
}

// Function to clear ARP table (silent version for iterations)
bool clearARPTable() {
    // Try ip command first (modern Linux)
    int result = system("ip neigh flush all 2>/dev/null");

    if (result == 0) {
        return true;
    }

    // Fallback to arp command (older systems)
    result = system("arp -d -a 2>/dev/null || arp -n | awk '/^[0-9]/ {system(\"arp -d \" $1)}' 2>/dev/null");

    return (result == 0);
}

// Function to check if running as root
bool isRoot() {
    return geteuid() == 0;
}

int main() {
    string ip;
    const int ITERATIONS = 1000;
    vector<double> allPingTimes;  // Store all ping times across iterations

    cout << "╔═══════════════════════════════════════╗" << endl;
    cout << "║  Ping and ARP Clear Utility (Linux)  ║" << endl;
    cout << "╚═══════════════════════════════════════╝" << endl;

    // Check if running as root
    if (!isRoot()) {
        cout << "\n⚠ Warning: Not running as root. ARP table clearing may fail." << endl;
        cout << "  Consider running with: sudo ./ping_arp\n" << endl;
    }

    cout << "\nEnter IP address to ping: ";
    getline(cin, ip);

    // Validate IP is not empty
    if (ip.empty()) {
        cerr << "Error: IP address cannot be empty!" << endl;
        return 1;
    }

    cout << "\n=== Starting " << ITERATIONS << " iterations ===" << endl;
    cout << "Target: " << ip << endl;
    cout << "This will take approximately " << (ITERATIONS * 2) << " seconds (~" << (ITERATIONS * 2 / 60) << " minutes)" << endl;
    cout << "\nPress Ctrl+C to stop at any time...\n" << endl;

    // Run 1000 iterations
    for (int i = 1; i <= ITERATIONS; i++) {
        vector<string> pingOutput;
        vector<double> pingTimes;

        cout << "--- Iteration " << i << "/" << ITERATIONS << " ---" << endl;

        // Execute ping and capture output
        string firstLine = executePingAndCapture(ip, pingOutput, pingTimes);

        // Display results for this iteration
        if (!firstLine.empty()) {
            cout << "First line: " << firstLine << endl;
        } else {
            cout << "No output captured from ping." << endl;
        }

        // Display ping times for this iteration
        if (!pingTimes.empty()) {
            cout << "Ping times: ";
            for (size_t j = 0; j < pingTimes.size(); j++) {
                cout << pingTimes[j] << " ms";
                if (j < pingTimes.size() - 1) {
                    cout << ", ";
                }
            }
            cout << endl;

            // Add to global collection
            allPingTimes.insert(allPingTimes.end(), pingTimes.begin(), pingTimes.end());
        } else {
            cout << "No ping times captured (host may be unreachable)" << endl;
        }

        // Clear ARP table
        cout << "Clearing ARP table... ";
        if (clearARPTable()) {
            cout << "Done." << endl;
        } else {
            cout << "Failed." << endl;
        }

        cout << endl;

        // Show progress every 50 iterations
        if (i % 50 == 0) {
            cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" << endl;
            cout << "Progress: " << i << "/" << ITERATIONS << " ("
                 << (i * 100 / ITERATIONS) << "%) completed" << endl;
            cout << "Total pings captured so far: " << allPingTimes.size() << endl;
            cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" << endl;
        }
    }

    cout << "\n╔═══════════════════════════════════════╗" << endl;
    cout << "║  ✓ All " << ITERATIONS << " iterations completed!     ║" << endl;
    cout << "╚═══════════════════════════════════════╝" << endl;

    // Calculate and display statistics
    if (!allPingTimes.empty()) {
        double sum = 0;
        double minTime = allPingTimes[0];
        double maxTime = allPingTimes[0];

        for (double time : allPingTimes) {
            sum += time;
            if (time < minTime) minTime = time;
            if (time > maxTime) maxTime = time;
        }

        double avgTime = sum / allPingTimes.size();

        cout << "\n=== Ping Statistics ===" << endl;
        cout << "Total pings: " << allPingTimes.size() << endl;
        cout << "Average time: " << avgTime << " ms" << endl;
        cout << "Minimum time: " << minTime << " ms" << endl;
        cout << "Maximum time: " << maxTime << " ms" << endl;

        // Display all times
        cout << "\n=== All Ping Times (ms) ===" << endl;
        for (size_t i = 0; i < allPingTimes.size(); i++) {
            cout << allPingTimes[i];
            if (i < allPingTimes.size() - 1) {
                cout << ", ";
            }
            // Add newline every 10 values for readability
            if ((i + 1) % 10 == 0) {
                cout << endl;
            }
        }
        cout << endl;
    } else {
        cout << "\nNo ping times were captured." << endl;
    }
    
    return 0;
}